import Foundation
struct LanguageInfo: Decodable {
    let language: String?
    let readAloudSupported: Bool
}
