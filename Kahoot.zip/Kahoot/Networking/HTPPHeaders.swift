
import Foundation

public typealias HTTPHeaders = [String: String]
