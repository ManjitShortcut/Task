
import Foundation

public enum HTTPTask {
    case request
}
