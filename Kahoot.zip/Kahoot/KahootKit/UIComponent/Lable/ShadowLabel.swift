
import UIKit
class ShadowLabel: UILabel {
    init() {
    }
}
